To start the program open "/x64/Release/Assignment 3 Particle Effects.exe"

Click anywhere on screen to create particle effects!


My work can be found in Source.cpp